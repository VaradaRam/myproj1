sap.ui.define([
	//	"sap/ui/core/mvc/Controller"
	"oft/fiori/controller/BaseController",
	"sap/m/MessageBox",
	"sap/m/MessageToast"
], function(Controller, MessageAPI, StatusMessage) {
	"use strict";

	return Controller.extend("oft.fiori.controller.View2", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf oft.fiori.view.View2
		 */
		onInit: function() {
			this.oRouter = this.getOwnerComponent().getRouter();
			this.oRouter.attachRoutePatternMatched(this.herculis, this);
		},

		herculis: function(oParams) {
			var sPath = oParams.getParameters().arguments.fruitId;
			sPath = "/fruits/" + sPath;
			this.getView().bindElement(sPath);
			//			console.log(oParams);
		},
		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf oft.fiori.view.View2
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf oft.fiori.view.View2
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf oft.fiori.view.View2
		 */
		//	onExit: function() {
		//
		//	}

		onBack: function() {
			this.getAppObject().to("idView1");
		},
		onButtonRam: function(){
			debugger;
			sap.m.MessageBox.alert("wow, you hovered");
		},
		popupClose: function(choice) {
			if (choice === "OK") {
				var oFirstTab = this.getView().byId("zumba");
				oFirstTab.setVisible(false);
				StatusMessage.show("Your request has been approved successfully!");
			}
		},

		onAccept: function() {
			MessageAPI.confirm("Would you like to Approve?", {
				title: "Ram",
				//			onClose: [this.popupClose, this]
				onClose: this.popupClose.bind(this)
			});
		},
		cityPopup: null,
		countryPopup: null,
		inputFieldIdOnWhichF4InTableWasPressed: null,
		onCityConfirm: function(oEvent) {
			var oItem = oEvent.getParameter("selectedItem");
			sap.ui.getCore().byId(this.inputFieldIdOnWhichF4InTableWasPressed).setValue(oItem.getTitle());
		},
		onF4Help: function(oEvent) {
			this.inputFieldIdOnWhichF4InTableWasPressed = oEvent.getSource().getId();
			//	StatusMessage.show("This page under construction...");
			if (this.cityPopup == null) {
				this.cityPopup = new sap.ui.xmlfragment("oft.fiori.fragments.Popup", this);
				this.getView().addDependent(this.cityPopup);
				this.cityPopup.bindAggregation("items", {
					path: "/cities",
					template: new sap.m.StandardListItem({
						title: "{city}",
						description: "{famousFor}"
					})
				});
				this.cityPopup.attachConfirm(this.onCityConfirm, this);
			}

			this.cityPopup.open();
		},

		onFilter: function() {
			//	StatusMessage.show("This page under construction...");
			this.countryPopup = new sap.ui.xmlfragment("oft.fiori.fragments.Popup", this);
			//		this.countryPopup.addDependent(this.getView());
			this.getView().addDependent(this.countryPopup);
			this.countryPopup.bindAggregation("items", {
				path: "/countries",
				template: new sap.m.StandardListItem({
					title: "{name}",
					description: "{code}"
				})
			});
			this.countryPopup.open();
		}

	});

});