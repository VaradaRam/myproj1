sap.ui.define([], function(){
//	sap.ui.core.extend("oft.fiori.controls.AmazingButton",{
	sap.m.Button.extend("oft.fiori.controls.AmazingButton",{
		metadata: {
			properties: {
				"zangoora": ""
			},
			events: {
				"rambutton": {}
			}
		},
		init: function(){},
		renderer:{},
		onmouseover: function(){
			this.fireRambutton();
		}
	})	;
});